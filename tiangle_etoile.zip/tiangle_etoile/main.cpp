#include <stdio.h>

int main()
{
   int x;

    printf("Donnez  la valeur de x \n");
    scanf("%d", &x);
    if(x>=0){
    for(int i=0;i<x;)
    {
        for(int j=0; j<=i;j++)
        {
            printf("x");
        }
        printf("\n");
        i=i+1;
    }
    }else
        printf("Soory");

    return 0;
}
